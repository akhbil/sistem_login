<?php
session_start();
// Jika sudah login, langsung arahkan ke dashboard
if (isset($_SESSION['status']) && $_SESSION['status'] == "login") {
    header("location:dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Sistem - Sistem Informasi Akademik</title>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: #f4f6f9; }
        .login-card { max-width: 400px; margin: 100px auto; border-radius: 12px; }
    </style>
</head>
<body>

<div class="container">
    <div class="card shadow-sm login-card">
        <div class="card-body p-4">
            <h4 class="text-center fw-bold mb-1">Portal Akademik</h4>
            <p class="text-center text-muted mb-4">Silakan login untuk masuk ke sistem</p>

            <?php if (isset($_GET['pesan'])): ?>
                <?php if ($_GET['pesan'] == "gagal"): ?>
                    <div class="alert alert-danger py-2 text-center">Username atau Password salah!</div>
                <?php elseif ($_GET['pesan'] == "logout"): ?>
                    <div class="alert alert-success py-2 text-center">Anda telah berhasil logout.</div>
                <?php elseif ($_GET['pesan'] == "belum_login"): ?>
                    <div class="alert alert-warning py-2 text-center">Silakan login terlebih dahulu.</div>
                <?php endif; ?>
            <?php endif; ?>

            <form action="proses_login.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" placeholder="Masukkan username" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-2">Masuk</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
