<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location:index.php?pesan=belum_login");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Informasi Akademik</title>
    <link href="https://jsdelivr.net" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Sistem Informasi Akademik</a>
        <div class="d-flex">
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="card shadow-sm border-0">
        <div class="card-body p-4">
            <h3 class="fw-bold">Selamat Datang, <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>!</h3>
            <p class="text-muted">Anda login sebagai: <span class="badge bg-success"><?php echo htmlspecialchars($_SESSION['role']); ?></span></p>
            <hr>
            <p>Ini adalah halaman <strong>Dashboard</strong> utama sistem. Sistem autentikasi (Login, Session Protection, dan Logout) telah berjalan dengan baik.</p>
        </div>
    </div>
</div>

</body>
</html>
