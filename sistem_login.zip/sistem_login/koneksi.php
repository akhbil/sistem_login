<?php
$host = "localhost";
$user = "root";
$pass = "root"; // Kosongkan jika menggunakan XAMPP default
$db   = "db_sistem_login";

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
